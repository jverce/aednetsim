#define NOMBRE_ARCHIVO "Datos.txt"

#define CICLOS_ACTUALIZACION 30

#define OTRA_COLUMNA ' '
#define OTRA_FILA '\n'

#define NUM_MAX_PAQ_POR_PAG 2000

#define NUM_MAX_ROUTERS 256

#define INF 999
#define PROPIO_ROUTER -1
