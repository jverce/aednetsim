#include "todos.h"

OtraClase :: OtraClase (double dNum)
{
	m_dNum = new double;
	*m_dNum = dNum;
}

OtraClase :: ~OtraClase ()
{
	delete m_dNum;
}

void OtraClase :: setNum (double dNum)
{
	*m_dNum = dNum;
}

void OtraClase :: setMc (MyClase* myClase)
{
	m_MyClase = myClase;
}

double OtraClase :: getNum ()
{
	return *m_dNum;
}
