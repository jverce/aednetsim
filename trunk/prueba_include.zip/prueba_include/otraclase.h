
class MyClase;

class OtraClase
{
	private:
		double* m_dNum;
		MyClase* m_MyClase;

	public:
		OtraClase (double dNum);
		~OtraClase ();
		void setNum (double dNum);
		void setMc (MyClase* myClase);
		double getNum ();
};
