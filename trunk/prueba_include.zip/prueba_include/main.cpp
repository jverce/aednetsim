#include <iostream>

#include "todos.h"

using namespace std;


int main ()
{
	MyClase mc(5, new OtraClase(5.5));

	mc.setNum(5, 10);
	cout << mc.getNum() << endl;
	mc.setNum(11);
	cout << mc.getNum() << endl;

	return 0;
}
