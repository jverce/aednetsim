#include <list>
#include <iostream>

#include "todos.h"


using namespace std;


MyClase :: MyClase (int iNum, OtraClase* otraClase)
{
	m_iNum = new int;
	*m_iNum = iNum;

	m_OtraClase = otraClase;

	list<int> lista;
	
	for (int i = 1; i <= *m_iNum; i++)
	{
		lista.push_back(i);
	}

	list<int> :: iterator it = lista.begin();
	while (it != lista.end())
	{
		cout << *it << endl;
		it++;
	}
}

MyClase :: ~MyClase ()
{
	delete m_iNum;
}

void MyClase :: setNum (int iNum)
{
	*m_iNum = iNum;
}

void MyClase :: setNum (int iNum1, int iNum2)
{
	*m_iNum = iNum1 * iNum2;
}

int MyClase :: getNum ()
{
	int iResult = (int) *m_iNum * (m_OtraClase -> getNum());
	return iResult;
}

OtraClase* MyClase :: getOc ()
{
	return m_OtraClase;
}
