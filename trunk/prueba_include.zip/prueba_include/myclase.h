
class MyClase
{
	private:
		int* m_iNum;
		OtraClase* m_OtraClase;

	public:
		MyClase (int iNum, OtraClase* otraClase);
		~MyClase ();
		void setNum (int iNum);
		void setNum (int iNum1, int iNum2);
		int getNum ();
		OtraClase* getOc ();
};
